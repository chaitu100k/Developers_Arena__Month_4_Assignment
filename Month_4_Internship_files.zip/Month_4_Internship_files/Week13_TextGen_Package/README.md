# Week 13: RNNs & LSTMs — Text Generation (Char-level)

This package replaces the forecasting notebooks with **text-generation LSTM** notebooks.
It includes:
- Week13_HandsOn_TextGen.ipynb  (char-level LSTM, short corpus, runnable)
- Week13_ClientProject_TextGen.ipynb (more modular client project, instructions to use larger corpora)
- Prettier PDFs exported from the notebooks (via nbconvert)
- evaluation_report.md summarizing results and interpretation
