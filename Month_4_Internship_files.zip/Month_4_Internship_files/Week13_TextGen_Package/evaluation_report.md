# Week13 Evaluation Report — Text Generation LSTM

## Summary
- Models: Char-level LSTM (hands-on small model; client project larger model)
- Training: 15 epochs (may be reduced for quick demos)
- Data: Hands-on uses a short builtin corpus. Client project notebook expects a larger text file at `/mnt/data/sample_corpus.txt`.

## Expected Results & Interpretation
- Small corpora produce repetitive, local patterns. For coherent output, use large corpora (millions of characters).
- Temperature controls creativity: lower -> conservative, higher -> more diverse but error-prone.
- Evaluation: Use qualitative human inspection, and optional metrics like perplexity or cross-entropy on a held-out set.

## Recommendations
- For better performance, train on a large corpus (e.g., Project Gutenberg, Shakespeare). Use GPU for speed.
- Consider word-level models or Transformer-based models (GPT-style) for more fluent generation.
- Save model checkpoints and keep training logs to compare hyperparameters.
