# Week 13: Recurrent Neural Networks (RNNs) and LSTMs

## Objectives
- Understand RNNs and LSTMs for sequence data.
- Learn how RNN/LSTM layers process sequential inputs and their uses.
- Implement LSTM models for time series forecasting and/or text generation.
- Evaluate model performance and save models for deployment.

## Deliverables
- Hands-On notebook and PDF: LSTM on a synthetic time series (forecasting).
- Client Project notebook and PDF: LSTM applied to a stock-like time series (synthetic) with model saving and evaluation.
- Python scripts are included in notebook cells; models are saved when notebooks run.

## Libraries
- TensorFlow / Keras
- NumPy, Matplotlib, pandas, scikit-learn (for metrics)

Run the notebooks end-to-end to train LSTM models (15 epochs). Adjust paths if running locally.
