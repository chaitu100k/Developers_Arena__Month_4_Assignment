# Week 12: Convolutional Neural Networks (CNNs)

## Objectives
- Understand the fundamentals of Convolutional Neural Networks (CNNs).
- Learn the different layers in a CNN — Convolution, Pooling, and Fully Connected layers.
- Implement CNNs for image classification tasks.
- Evaluate model performance using accuracy and loss metrics.

## Deliverables
- Hands-On notebook and PDF (training CIFAR-10 with TensorFlow/Keras, full version - 15 epochs)
- Client Project notebook and PDF (CIFAR-10 project script, model save, evaluation)
